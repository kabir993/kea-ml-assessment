import os
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

model = genai.GenerativeModel("gemini-1.5-flash")


def generate_response(name, category, message):

    prompt = f"""
    You are a professional AI sales assistant.

    Generate a personalized response.

    User Name:
    {name}

    Lead Category:
    {category}

    User Message:
    {message}

    Rules:
    - professional tone
    - concise
    - context-aware
    - avoid generic responses
    - include CTA
    """

    try:

        response = model.generate_content(prompt)

        return response.text.strip()

    except Exception as e:

        print("Response Generation Error:", e)

        # Fallback response
        return f"""
Hi {name},

Thank you for reaching out.
Our team will get back to you shortly.
"""