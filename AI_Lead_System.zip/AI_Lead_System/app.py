from fastapi import FastAPI
from pydantic import BaseModel

from classifier import classify_lead
from response_generator import generate_response

app = FastAPI()


class Lead(BaseModel):
    name: str
    email: str
    company: str
    message: str

    class Config:
        min_anystr_length = 1


@app.post("/process-lead")
def process_lead(lead: Lead):

    try:

        classification = classify_lead(lead.message)

        response = generate_response(
            name=lead.name,
            category=classification["category"],
            message=lead.message
        )

        return {
            "lead_category": classification["category"],
            "confidence": classification["confidence"],
            "response": response
        }

    except Exception as e:

        return {
            "error": "Internal server error",
            "details": str(e)
        }
    