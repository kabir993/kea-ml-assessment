import os
import json
import google.generativeai as genai
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure Gemini API
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

# Load Gemini model
model = genai.GenerativeModel("gemini-1.5-flash")


def classify_lead(message):

    # Garbage input detection
    if len(message.strip()) < 5:
        return {
            "category": "Cold",
            "confidence": "Low"
        }

    prompt = f"""
    You are an AI lead qualification assistant.

    Your task is to classify leads into:
    - Hot
    - Warm
    - Cold

    Rules:
    - Hot = strong buying intent
    - Warm = exploring/interested
    - Cold = vague or low intent

    Allowed confidence values:
    - High
    - Medium
    - Low

    Return ONLY valid JSON.

    Example:
    {{
      "category": "Hot",
      "confidence": "High"
    }}

    Lead Message:
    {message}
    """

    try:

        # Generate response from Gemini
        response = model.generate_content(prompt)

        # Extract text
        result = response.text.strip()

        # Clean markdown formatting if Gemini returns ```json
        result = result.replace("```json", "")
        result = result.replace("```", "")
        result = result.strip()

        # Convert string to Python dictionary
        return json.loads(result)

    except Exception as e:

        print("Classification Error:", e)

        # Safe fallback classification
        return {
            "category": "Cold",
            "confidence": "Low"
        }
    