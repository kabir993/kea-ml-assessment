Current Implementation:
- Gemini LLM-based lead classification
- confidence scoring
- fallback handling

Classification is performed using prompt-based AI inference with structured JSON output.

Future Improvements:
- fine-tuned lead scoring
- feedback learning loop
- multi-model evaluation
- human review pipeline