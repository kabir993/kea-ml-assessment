# AI Lead Qualification System

## Overview

This project is an AI-powered lead qualification and smart response system built using FastAPI and Gemini AI.

The system:
- receives lead input
- classifies leads into Hot/Warm/Cold categories
- generates AI-powered personalized responses
- handles edge cases and failures
- supports scalable production-aware architecture

---

# Features

- FastAPI backend
- Gemini AI-powered lead classification
- AI-generated personalized responses
- Prompt-based AI workflow
- Swagger API testing
- Fallback handling
- Production-aware architecture

---

# Tech Stack

- Python
- FastAPI
- Gemini AI
- Uvicorn
- python-dotenv

---

# API Endpoint

POST /process-lead

---

# Run Project

## Create Virtual Environment

python -m venv venv

---

## Activate Environment

Windows:
venv\Scripts\activate

---

## Install Dependencies

pip install -r requirements.txt

---

## Configure Environment Variables

Create a `.env` file in the project root:

GEMINI_API_KEY=your_api_key_here

---

## Run Server

uvicorn app:app --reload

---

## Open Swagger UI

http://127.0.0.1:8000/docs

---

# System Workflow

User Input
→ FastAPI API
→ AI Lead Classification
→ AI Response Generation
→ JSON Response Output

---

# Edge Case Handling

The system handles:
- low/garbage input
- model/API failure
- invalid AI responses
- fallback response generation

---

# Future Improvements

- PostgreSQL integration
- Redis/Celery async queues
- CRM integrations
- Advanced lead scoring
- Retry orchestration
- Monitoring dashboards
- RAG/vector memory
- Multi-model evaluation